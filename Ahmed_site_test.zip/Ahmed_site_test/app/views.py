from django.shortcuts import render
from .models import *
# Create your views here.
def home(request):
    thanks = ""
    if request.method == "POST":
        Ahmed(name=request.POST["name"]).save()
        thanks=f"thanks {request.POST['name']} for testing my site"
    return render(request,"home.html",{"thanks":thanks})